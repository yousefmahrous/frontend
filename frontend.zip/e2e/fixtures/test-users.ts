export const CUSTOMER = {
  email: 'youssefmahrous445@gmail.com',
  password: '123456',
};

export const ADMIN = {
  email: 'admin@admin.com',
  password: 'admin123',
};