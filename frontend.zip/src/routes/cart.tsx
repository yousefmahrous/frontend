import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, Loader2, Minus, Plus, ShoppingCart, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { errorMessage } from "@/api/client";
import type { CartItem } from "@/api/cart.api";
import { Protected } from "@/components/Guards";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useCart, useRemoveCartItem, useUpdateCartItem } from "@/hooks/useCart";
import { useCheckout } from "@/hooks/usePayment";

export const Route = createFileRoute("/cart")({
  ssr: false,
  head: () => ({
    meta: [{ title: "عربيتي | مكتبة القراء" }],
  }),
  component: () => (
    <Protected>
      <CartPage />
    </Protected>
  ),
});

function CartPage() {
  const { data: cart, isLoading, isError, error, refetch } = useCart();
  const checkout = useCheckout();

  if (isLoading) {
    return (
      <div className="mx-auto max-w-3xl space-y-4 px-4 py-10">
        <Skeleton className="h-8 w-40" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  if (isError) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-14">
        <ErrorState message={errorMessage(error)} onRetry={() => void refetch()} />
      </div>
    );
  }

  const items = cart?.items ?? [];

  // السعر مخزن بالقرش، فبنقسمه على 100 عشان نعرضه للمستخدم بالجنيه
  const totalPrice = items.reduce(
    (sum, item) => sum + (item.book.price * item.quantity) / 100,
    0,
  );

  function handleCheckout() {
    checkout.mutate(undefined, {
      onError: (err) => toast.error(errorMessage(err)),
    });
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <div className="mb-6 flex items-center gap-3">
        <ShoppingCart className="size-6 text-accent" />
        <h1 className="text-2xl font-extrabold">عربيتي</h1>
        {items.length > 0 && <Badge variant="secondary">{cart?.itemsCount} كتاب</Badge>}
      </div>

      {items.length === 0 ? (
        <EmptyState
          title="العربية فاضية"
          description="لسه ما ضفتش أي كتاب. روح تصفح الكتالوج وضيف اللي يعجبك."
        />
      ) : (
        <>
          <div className="space-y-4">
            {items.map((item) => (
              <CartItemCard key={item.id} item={item} />
            ))}
          </div>

          <div className="mt-6 flex items-center justify-between rounded-xl border border-border bg-card p-4 shadow-sm">
            <div>
              <p className="text-sm text-muted-foreground">الإجمالي</p>
              <p className="text-xl font-extrabold">{totalPrice.toFixed(2)} جنيه</p>
            </div>
            <Button onClick={handleCheckout} disabled={checkout.isPending}>
              {checkout.isPending ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                "المتابعة للدفع"
              )}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}


function CartItemCard({ item }: { item: CartItem }) {
  const updateQuantity = useUpdateCartItem();
  const removeItem = useRemoveCartItem();

  const isBusy = updateQuantity.isPending || removeItem.isPending;

  function handleQuantityChange(newQuantity: number) {
    if (newQuantity < 1) return;
    updateQuantity.mutate(
      { itemId: item.id, quantity: newQuantity },
      { onError: (err) => toast.error(errorMessage(err)) },
    );
  }

  function handleRemove() {
    removeItem.mutate(item.id, {
      onSuccess: (res) => toast.success(res.message),
      onError: (err) => toast.error(errorMessage(err)),
    });
  }

  return (
    <div className="flex gap-4 rounded-xl border border-border bg-card p-4 shadow-sm">
      <Link
        to="/books/$id"
        params={{ id: item.book.id }}
        className="shrink-0 overflow-hidden rounded-lg border border-border bg-secondary"
      >
        {item.book.avatar_url ? (
          <img
            src={item.book.avatar_url}
            alt={`غلاف كتاب ${item.book.name}`}
            className="aspect-2/3 w-20 object-cover"
          />
        ) : (
          <div className="flex aspect-2/3 w-20 items-center justify-center text-muted-foreground">
            <BookOpen className="size-6" />
          </div>
        )}
      </Link>

      <div className="flex flex-1 flex-col justify-between gap-3">
        <div>
          <Badge variant="secondary" className="mb-1">
            {item.book.category}
          </Badge>
          <Link
            to="/books/$id"
            params={{ id: item.book.id }}
            className="block font-bold hover:text-accent"
          >
            {item.book.name}
          </Link>
          <p className="text-xs text-muted-foreground">ISBN: {item.book.number}</p>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 rounded-lg border border-border">
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              disabled={isBusy || item.quantity <= 1}
              onClick={() => handleQuantityChange(item.quantity - 1)}
              aria-label="تقليل الكمية"
            >
              <Minus className="size-3.5" />
            </Button>
            <span className="w-6 text-center text-sm font-semibold">
              {updateQuantity.isPending ? (
                <Loader2 className="mx-auto size-3.5 animate-spin" />
              ) : (
                item.quantity
              )}
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              disabled={isBusy || item.book.stock <= 0}
              onClick={() => handleQuantityChange(item.quantity + 1)}
              aria-label="زيادة الكمية"
            >
              <Plus className="size-3.5" />
            </Button>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="text-destructive hover:bg-destructive/10 hover:text-destructive"
            disabled={isBusy}
            onClick={handleRemove}
            aria-label="حذف من العربية"
          >
            {removeItem.isPending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Trash2 className="size-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}